import { configureStore } from '@reduxjs/toolkit'
import { createSlice } from '@reduxjs/toolkit'

const counterSlice = createSlice({
  name: 'counter',
  initialState: {
    value: 0,
  },
  reducers: {
    increment: state => {
      state.value += 1;
    },
    decrement: state => {
      state.value -= 1;
    },
    incrementByAmount: (state, action) => {
      state.value += action.payload;
    },
  },
});

const sidebarSlice = createSlice({
  name: 'sidebar',
  initialState: {
    value: false,
  },
  reducers: {
    toggle: state => {
      state.value = !state.value;
    }
  },
});

const store = configureStore({ 
  reducer: {
    counter:counterSlice.reducer,
    sidebarmode:sidebarSlice.reducer
  }
})

export const { increment,decrement } = counterSlice.actions
export const { toggle }=sidebarSlice.actions

export default store
