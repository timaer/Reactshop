import "./index.css";
import {useSelector,useDispatch} from 'react-redux';
import {toggle} from 'redux/store'

function ReduxPage(){
    const sidebarStatus = useSelector((state)=>state.sidebarmode.value);
    const dispatch  = useDispatch();

    return(
       <div className="login-container">
           <div className="login-form">
                  <div className="login-title">后台管理系统redux测试页</div>
                  <div>获取store变量:{sidebarStatus.toString()}</div>
                  <button onClick={()=>dispatch(toggle())}>点击测试</button>
           </div>
       </div>
    )  
}

export default ReduxPage