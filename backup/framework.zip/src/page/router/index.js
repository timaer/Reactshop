import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import App from 'page/app'
import ReduxPage from 'page/redux'
import AxiosPage from 'page/axios'
import './index.css'

function RouterPage(){
   return( 
      <Router>
        <div className='app'>  
            <div  className='sidenav'>  
                <ul>
                    <li>
                        <Link to='/choose'>选择页</Link>    
                    </li>
                    <li>
                        <Link to='/login'>登陆页</Link>
                    </li>
                    <li>
                        <Link to='/axios'>沟通页</Link>
                    </li>
                </ul>
            </div>
            <div className='maincontent'>    
                <Switch>
                    <Route path='/choose'>
                    <App />
                    </Route>
                    <Route path='/login'>
                    <ReduxPage/>
                    </Route>
                    <Route path='/axios'>
                    <AxiosPage/>
                    </Route>
                </Switch>
            </div>
       </div> 
      </Router>   
   )
}

export default RouterPage