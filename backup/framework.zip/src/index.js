import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import './responsive'
import store from './redux/store'
import { Provider } from 'react-redux'

import RouterPage from 'page/router';

ReactDOM.render(
  <Provider store={store}>
    <RouterPage />
  </Provider>,
  document.getElementById('root')
);

